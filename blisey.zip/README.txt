
NOTE:

By installing or using this font, you are agree to the Product Usage Agreement:
- This demo font is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!

- Here is the link to purchase full version and commercial license: 
https://www.myfonts.com/collections/blisey-font-syauqi-studio

- For Corporate use you have to purchase Corporate license


Please visit our store for more amazing fonts :
https://www.myfonts.com/collections/syauqi-studio-foundry


Any question for license contact:
syauqistudios@gmail.com


Thank you, Best regards
Syauqi Studio


